<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rural_development";
$tablename="problems"
$port = 3306;

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process regular form fields
    $checkbox1 = isset($_POST['checkbox1']) ? "Checked" : "Not Checked";
    $checkbox2 = isset($_POST['checkbox2']) ? "Checked" : "Not Checked";
    $checkbox3 = isset($_POST['checkbox3']) ? "Checked" : "Not Checked";
    $checkbox4 = isset($_POST['checkbox4']) ? "Checked" : "Not Checked";
    $checkbox5 = isset($_POST['checkbox5']) ? "Checked" : "Not Checked";
    $checkbox6 = isset($_POST['checkbox6']) ? "Checked" : "Not Checked";
    $checkbox7 = isset($_POST['checkbox7']) ? "Checked" : "Not Checked";
    $checkbox8 = isset($_POST['checkbox8']) ? "Checked" : "Not Checked";
    $textarea1 = $_POST['textarea1'];
    $textarea2 = $_POST['textarea2'];
    
    // Process speech recognition output
    $speechOutput = isset($_POST['output']) ? $_POST['output'] : "";

    // File upload handling
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        $file_status = "File uploaded successfully";
    } else {
        $file_status = "Error uploading file";
    }

    // Now, you can save all these variables into your database
    // Use appropriate database connection and query here

    // For example, using mysqli:
    // $conn = new mysqli($servername, $username, $password, $dbname);
    // $sql = "INSERT INTO your_table_name (checkbox1, checkbox2, ..., textarea1, textarea2, speech_output, file_status) 
    //         VALUES ('$checkbox1', '$checkbox2', ..., '$textarea1', '$textarea2', '$speechOutput', '$file_status')";
    // $conn->query($sql);
    // $conn->close();
}

?>