<!-- $con = mysqli_connect('localhost', 'root', '','db_contact');
The “db_contact” is our database name that we created before.
After connection database you need to take post variable from the form. See the below code
$txtName = $_POST['txtName'];
$txtEmail = $_POST['txtEmail'];
$txtPhone = $_POST['txtPhone'];
$txtMessage = $_POST['txtMessage']; -->

 <?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

// $con = mysqli_connect('localhost', 'root', '','db_contact');

// get the post records
// $txtName = $_POST['txtName'];
// $txtEmail = $_POST['txtEmail'];
// $txtPhone = $_POST['txtPhone'];
// $txtMessage = $_POST['txtMessage'];

// database insert SQL code
// $sql = "INSERT INTO `tbl_contact` (`Id`, `fldName`, `fldEmail`, `fldPhone`, `fldMessage`) VALUES ('0', '$txtName', '$txtEmail', '$txtPhone', '$txtMessage')";

// insert in database 
// $rs = mysqli_query($con, $sql);

// if($rs)
// {
// 	echo "Contact Records Inserted";
// }else{
//     echp "Something went wrong"
// }

// 


	// $firstName = $_POST['firstName'];
	// $lastName = $_POST['lastName'];
	// $gender = $_POST['gender'];
	// $email = $_POST['email'];
	// $password = $_POST['password'];
	// $number = $_POST['number'];
    $txtName = $_POST['txtName'];
$txtEmail = $_POST['txtEmail'];
$txtPhone = $_POST['txtPhone'];
$txtMessage = $_POST['txtMessage'];

	// Database connection
	$conn = new mysqli('localhost','root','','db_contact');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into tbl_contact( `id`,`fldName`, `fldEmail`, `fldPhone`, `fldMessage`) values(?, ?, ?, ?, ?)");
		$stmt->bind_param("issis", 0, $txtName, $txtEmail, $txtPhone, $txtMessage);
		$execval = $stmt->execute();
		echo $execval;
		echo "Updated successfully...";
		$stmt->close();
		$conn->close();
	}
?>